import { useState, useEffect } from 'react';
import { LoginScreen } from './components/LoginScreen';
import { HomeScreen } from './components/HomeScreen';
import { AddTaskScreen } from './components/AddTaskScreen';
import { ListsScreen } from './components/ListsScreen';
import { MonthlyTasksScreen } from './components/MonthlyTasksScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { TaskHistoryScreen } from './components/TaskHistoryScreen';
import { BottomNav } from './components/BottomNav';
import {
  getCurrentUser,
  logout as logoutUser,
  getTasks,
  saveTasks,
  initializeDemoAccount,
  type User,
  type Task,
} from './utils/storage';

type Screen = 'home' | 'add' | 'lists' | 'monthly' | 'settings' | 'history';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isAddingMonthlyTask, setIsAddingMonthlyTask] = useState(false);

  // Check for existing session on mount
  useEffect(() => {
    // Initialize demo account
    initializeDemoAccount();
    
    const user = getCurrentUser();
    if (user) {
      setCurrentUser(user);
      loadUserTasks(user.id);
    }
  }, []);

  const loadUserTasks = (userId: string) => {
    const userTasks = getTasks(userId);
    setTasks(userTasks);
  };

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    loadUserTasks(user.id);
  };

  const handleLogout = () => {
    logoutUser();
    setCurrentUser(null);
    setTasks([]);
    setCurrentScreen('home');
  };

  const handleAddTask = (title: string, category: string, dueDate?: string) => {
    if (!currentUser) return;

    const newTask: Task = {
      id: Date.now().toString(),
      title,
      completed: false,
      category,
      userId: currentUser.id,
      createdAt: new Date().toISOString(),
      dueDate,
      isMonthlyTask: !!dueDate,
    };

    const updatedTasks = [newTask, ...tasks];
    setTasks(updatedTasks);
    saveTasks(currentUser.id, updatedTasks);
    setIsAddingMonthlyTask(false);
  };

  const handleToggleTask = (id: string) => {
    if (!currentUser) return;

    const updatedTasks = tasks.map((task) =>
      task.id === id ? { ...task, completed: !task.completed } : task
    );
    setTasks(updatedTasks);
    saveTasks(currentUser.id, updatedTasks);
  };

  const handleDeleteTask = (id: string) => {
    if (!currentUser) return;

    const updatedTasks = tasks.filter((task) => task.id !== id);
    setTasks(updatedTasks);
    saveTasks(currentUser.id, updatedTasks);
  };

  const handleAddMonthlyTask = () => {
    setIsAddingMonthlyTask(true);
    setCurrentScreen('add');
  };

  const handleNavigate = (screen: Screen) => {
    setCurrentScreen(screen);
    if (screen !== 'add') {
      setIsAddingMonthlyTask(false);
    }
  };

  // Show login screen if not authenticated
  if (!currentUser) {
    return (
      <div className="size-full flex items-center justify-center bg-gray-100">
        <div className="w-full max-w-md h-full bg-white shadow-2xl">
          <LoginScreen onLogin={handleLogin} />
        </div>
      </div>
    );
  }

  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return (
          <HomeScreen
            tasks={tasks}
            onToggleTask={handleToggleTask}
            onDeleteTask={handleDeleteTask}
          />
        );
      case 'add':
        return (
          <AddTaskScreen
            onAddTask={handleAddTask}
            onNavigate={handleNavigate}
            isMonthlyTask={isAddingMonthlyTask}
          />
        );
      case 'lists':
        return <ListsScreen tasks={tasks} />;
      case 'monthly':
        return (
          <MonthlyTasksScreen
            tasks={tasks}
            onToggleTask={handleToggleTask}
            onDeleteTask={handleDeleteTask}
            onAddMonthlyTask={handleAddMonthlyTask}
          />
        );
      case 'settings':
        return <SettingsScreen user={currentUser} onLogout={handleLogout} onViewHistory={() => handleNavigate('history')} />;
      case 'history':
        return <TaskHistoryScreen tasks={tasks} onBack={() => handleNavigate('settings')} />;
      default:
        return null;
    }
  };

  return (
    <div className="size-full flex items-center justify-center bg-gray-100">
      {/* Mobile App Container */}
      <div className="w-full max-w-md h-full bg-white shadow-2xl flex flex-col relative">
        {/* Screen Content */}
        <div className="flex-1 overflow-hidden pb-16">
          {renderScreen()}
        </div>

        {/* Bottom Navigation */}
        <BottomNav currentScreen={currentScreen} onNavigate={handleNavigate} />
      </div>
    </div>
  );
}