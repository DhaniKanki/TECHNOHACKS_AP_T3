import { History, Calendar, Check, X, ArrowLeft } from 'lucide-react';
import type { Task } from '../utils/storage';

interface TaskHistoryScreenProps {
  tasks: Task[];
  onBack: () => void;
}

export function TaskHistoryScreen({ tasks, onBack }: TaskHistoryScreenProps) {
  // Sort tasks by creation date (newest first)
  const sortedTasks = [...tasks].sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.completed).length;
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 mb-4 hover:bg-white/20 px-3 py-2 rounded-lg transition-colors -ml-3"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back</span>
        </button>
        
        <div className="flex items-center gap-2 mb-4">
          <History className="w-6 h-6" />
          <h1 className="text-2xl">Task History</h1>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mt-4">
          <div className="bg-white/20 rounded-lg p-3 text-center">
            <div className="text-2xl mb-1">{totalTasks}</div>
            <div className="text-xs text-purple-100">Total</div>
          </div>
          <div className="bg-white/20 rounded-lg p-3 text-center">
            <div className="text-2xl mb-1">{completedTasks}</div>
            <div className="text-xs text-purple-100">Completed</div>
          </div>
          <div className="bg-white/20 rounded-lg p-3 text-center">
            <div className="text-2xl mb-1">{completionRate}%</div>
            <div className="text-xs text-purple-100">Success</div>
          </div>
        </div>
      </div>

      {/* Task Timeline */}
      <div className="flex-1 overflow-auto p-4">
        {sortedTasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 px-6">
            <div className="text-6xl mb-4">📊</div>
            <h2 className="text-xl text-gray-600 mb-2">No history yet</h2>
            <p className="text-gray-400 text-center">
              Your task history will appear here
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {sortedTasks.map((task) => (
              <div
                key={task.id}
                className="bg-white rounded-lg p-4 shadow-sm"
              >
                <div className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    task.completed ? 'bg-green-100' : 'bg-gray-100'
                  }`}>
                    {task.completed ? (
                      <Check className="w-4 h-4 text-green-600" />
                    ) : (
                      <X className="w-4 h-4 text-gray-400" />
                    )}
                  </div>

                  <div className="flex-1">
                    <h3 className={`mb-1 ${task.completed ? 'text-gray-600 line-through' : 'text-gray-900'}`}>
                      {task.title}
                    </h3>
                    
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <span className="px-2 py-1 bg-blue-50 text-blue-600 rounded">
                        {task.category}
                      </span>
                      
                      {task.dueDate && (
                        <span className="flex items-center gap-1 text-gray-500">
                          <Calendar className="w-3 h-3" />
                          {new Date(task.dueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                        </span>
                      )}
                      
                      <span className="text-gray-400">
                        • Created {formatDate(task.createdAt)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}