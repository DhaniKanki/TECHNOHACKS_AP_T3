import { TodoItem } from './TodoItem';

interface Task {
  id: string;
  title: string;
  completed: boolean;
  category: string;
}

interface HomeScreenProps {
  tasks: Task[];
  onToggleTask: (id: string) => void;
  onDeleteTask: (id: string) => void;
}

export function HomeScreen({ tasks, onToggleTask, onDeleteTask }: HomeScreenProps) {
  const activeTasks = tasks.filter((task) => !task.completed);
  const completedTasks = tasks.filter((task) => task.completed);

  return (
    <div className="flex flex-col h-full bg-gray-50">
      <div className="bg-blue-600 text-white p-6">
        <h1 className="text-2xl">My Tasks</h1>
        <p className="text-blue-100 mt-1">
          {activeTasks.length} active · {completedTasks.length} completed
        </p>
      </div>

      <div className="flex-1 overflow-auto">
        {tasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 px-6">
            <div className="text-6xl mb-4">📝</div>
            <h2 className="text-xl text-gray-600 mb-2">No tasks yet</h2>
            <p className="text-gray-400 text-center">
              Tap the + button to add your first task
            </p>
          </div>
        ) : (
          <>
            {activeTasks.length > 0 && (
              <div className="mb-6">
                <h2 className="text-sm text-gray-500 px-4 py-2 bg-gray-100">
                  ACTIVE TASKS
                </h2>
                <div className="bg-white">
                  {activeTasks.map((task) => (
                    <TodoItem
                      key={task.id}
                      {...task}
                      onToggle={onToggleTask}
                      onDelete={onDeleteTask}
                    />
                  ))}
                </div>
              </div>
            )}

            {completedTasks.length > 0 && (
              <div>
                <h2 className="text-sm text-gray-500 px-4 py-2 bg-gray-100">
                  COMPLETED
                </h2>
                <div className="bg-white">
                  {completedTasks.map((task) => (
                    <TodoItem
                      key={task.id}
                      {...task}
                      onToggle={onToggleTask}
                      onDelete={onDeleteTask}
                    />
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
