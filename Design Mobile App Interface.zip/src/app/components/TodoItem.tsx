import { Circle, CircleCheck, Trash2 } from 'lucide-react';

interface TodoItemProps {
  id: string;
  title: string;
  completed: boolean;
  category: string;
  dueDate?: string;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

export function TodoItem({ id, title, completed, category, dueDate, onToggle, onDelete }: TodoItemProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return 'Tomorrow';
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
  };

  return (
    <div className="flex items-center gap-3 p-4 bg-white border-b border-gray-100 active:bg-gray-50 transition-colors">
      <button
        onClick={() => onToggle(id)}
        className="flex-shrink-0"
        aria-label={completed ? "Mark as incomplete" : "Mark as complete"}
      >
        {completed ? (
          <CircleCheck className="w-6 h-6 text-green-500" />
        ) : (
          <Circle className="w-6 h-6 text-gray-300" />
        )}
      </button>
      
      <div className="flex-1 min-w-0">
        <p className={`${completed ? 'line-through text-gray-400' : 'text-gray-900'}`}>
          {title}
        </p>
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <span>{category}</span>
          {dueDate && (
            <>
              <span>•</span>
              <span className="text-blue-600">{formatDate(dueDate)}</span>
            </>
          )}
        </div>
      </div>
      
      <button
        onClick={() => onDelete(id)}
        className="flex-shrink-0 p-2 hover:bg-gray-100 rounded-full transition-colors"
        aria-label="Delete task"
      >
        <Trash2 className="w-5 h-5 text-red-500" />
      </button>
    </div>
  );
}