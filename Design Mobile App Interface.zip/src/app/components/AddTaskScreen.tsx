import { useState } from 'react';
import { Check } from 'lucide-react';

interface AddTaskScreenProps {
  onAddTask: (title: string, category: string, dueDate?: string) => void;
  onNavigate: (screen: string) => void;
  isMonthlyTask?: boolean;
}

export function AddTaskScreen({ onAddTask, onNavigate, isMonthlyTask = false }: AddTaskScreenProps) {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Personal');
  const [dueDate, setDueDate] = useState('');

  const categories = ['Personal', 'Work', 'Shopping', 'Health', 'Other'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (title.trim()) {
      onAddTask(title, category, dueDate || undefined);
      setTitle('');
      setDueDate('');
      onNavigate('home');
    }
  };

  return (
    <div className="flex flex-col h-full bg-gray-50">
      <div className="bg-blue-600 text-white p-6">
        <h1 className="text-2xl">{isMonthlyTask ? 'Add Monthly Task' : 'Add New Task'}</h1>
      </div>

      <form onSubmit={handleSubmit} className="flex-1 p-6 space-y-6">
        <div>
          <label htmlFor="task-title" className="block mb-2 text-gray-700">
            Task Title
          </label>
          <input
            id="task-title"
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Enter task title..."
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            autoFocus
          />
        </div>

        <div>
          <label htmlFor="task-category" className="block mb-2 text-gray-700">
            Category
          </label>
          <select
            id="task-category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="task-due-date" className="block mb-2 text-gray-700">
            Due Date (Optional)
          </label>
          <input
            id="task-due-date"
            type="date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-3 rounded-lg flex items-center justify-center gap-2 hover:bg-blue-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
          disabled={!title.trim()}
        >
          <Check className="w-5 h-5" />
          Add Task
        </button>
      </form>
    </div>
  );
}