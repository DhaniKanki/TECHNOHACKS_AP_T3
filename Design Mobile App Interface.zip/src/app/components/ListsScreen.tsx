import { ChevronRight } from 'lucide-react';

interface Task {
  id: string;
  title: string;
  completed: boolean;
  category: string;
}

interface ListsScreenProps {
  tasks: Task[];
}

export function ListsScreen({ tasks }: ListsScreenProps) {
  const categories = ['Personal', 'Work', 'Shopping', 'Health', 'Other'];

  const getCategoryCount = (category: string) => {
    return tasks.filter((task) => task.category === category && !task.completed).length;
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      Personal: 'bg-blue-500',
      Work: 'bg-purple-500',
      Shopping: 'bg-green-500',
      Health: 'bg-red-500',
      Other: 'bg-gray-500',
    };
    return colors[category] || 'bg-gray-500';
  };

  return (
    <div className="flex flex-col h-full bg-gray-50">
      <div className="bg-blue-600 text-white p-6">
        <h1 className="text-2xl">My Lists</h1>
        <p className="text-blue-100 mt-1">
          {tasks.filter((t) => !t.completed).length} active tasks
        </p>
      </div>

      <div className="flex-1 overflow-auto p-4 space-y-2">
        {categories.map((category) => {
          const count = getCategoryCount(category);
          return (
            <div
              key={category}
              className="bg-white rounded-lg p-4 flex items-center justify-between shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full ${getCategoryColor(category)} flex items-center justify-center text-white`}>
                  {count}
                </div>
                <div>
                  <h3 className="text-gray-900">{category}</h3>
                  <p className="text-sm text-gray-500">
                    {count} {count === 1 ? 'task' : 'tasks'}
                  </p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </div>
          );
        })}
      </div>
    </div>
  );
}
