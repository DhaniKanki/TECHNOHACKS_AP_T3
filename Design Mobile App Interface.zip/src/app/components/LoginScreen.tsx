import { useState } from 'react';
import { LogIn, UserPlus, Lock, CircleUser } from 'lucide-react';
import { findUser, getUserByEmail, saveUser, saveCurrentUser, type User, type StoredUser } from '../utils/storage';

interface LoginScreenProps {
  onLogin: (user: User) => void;
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [isSignup, setIsSignup] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }

    if (isSignup) {
      // Sign up
      if (!name) {
        setError('Please enter your name');
        return;
      }

      const existingUser = getUserByEmail(email);
      if (existingUser) {
        setError('Email already registered');
        return;
      }

      const newUser: StoredUser = {
        id: Date.now().toString(),
        email,
        password, // NOTE: In production, hash passwords!
        name,
      };

      saveUser(newUser);
      const { password: _, ...userWithoutPassword } = newUser;
      saveCurrentUser(userWithoutPassword);
      onLogin(userWithoutPassword);
    } else {
      // Login
      const user = findUser(email, password);
      if (!user) {
        setError('Invalid email or password');
        return;
      }

      const { password: _, ...userWithoutPassword } = user;
      saveCurrentUser(userWithoutPassword);
      onLogin(userWithoutPassword);
    }
  };

  return (
    <div className="flex flex-col h-full bg-gradient-to-br from-blue-500 to-purple-600">
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          {/* Logo/Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-white rounded-full mb-4 shadow-lg">
              <span className="text-4xl">✓</span>
            </div>
            <h1 className="text-3xl text-white mb-2">TaskMaster</h1>
            <p className="text-blue-100">Organize your life, one task at a time</p>
          </div>

          {/* Login/Signup Form */}
          <div className="bg-white rounded-2xl shadow-2xl p-6">
            <div className="flex mb-6 bg-gray-100 rounded-lg p-1">
              <button
                onClick={() => {
                  setIsSignup(false);
                  setError('');
                }}
                className={`flex-1 py-2 rounded-md transition-colors ${
                  !isSignup ? 'bg-white text-blue-600 shadow' : 'text-gray-600'
                }`}
              >
                Login
              </button>
              <button
                onClick={() => {
                  setIsSignup(true);
                  setError('');
                }}
                className={`flex-1 py-2 rounded-md transition-colors ${
                  isSignup ? 'bg-white text-blue-600 shadow' : 'text-gray-600'
                }`}
              >
                Sign Up
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {isSignup && (
                <div>
                  <label htmlFor="name" className="block text-sm text-gray-700 mb-1">
                    Full Name
                  </label>
                  <div className="relative">
                    <CircleUser className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      id="name"
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="John Doe"
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              )}

              <div>
                <label htmlFor="email" className="block text-sm text-gray-700 mb-1">
                  Email
                </label>
                <div className="relative">
                  <CircleUser className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="password" className="block text-sm text-gray-700 mb-1">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {error && (
                <div className="bg-red-50 text-red-600 px-4 py-2 rounded-lg text-sm">
                  {error}
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-3 rounded-lg flex items-center justify-center gap-2 hover:bg-blue-700 transition-colors"
              >
                {isSignup ? (
                  <>
                    <UserPlus className="w-5 h-5" />
                    Create Account
                  </>
                ) : (
                  <>
                    <LogIn className="w-5 h-5" />
                    Login
                  </>
                )}
              </button>
            </form>

            <div className="mt-4 p-3 bg-blue-50 rounded-lg">
              <p className="text-xs text-blue-800 mb-1">💡 Quick Start</p>
              <p className="text-xs text-blue-600">
                Create a new account or use demo credentials:
                <br />
                <span className="font-mono">demo@example.com / demo123</span>
              </p>
            </div>

            <p className="text-xs text-gray-500 text-center mt-4">
              Demo app - Data stored locally in browser
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}