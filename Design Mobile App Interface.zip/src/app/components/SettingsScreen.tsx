import { ChevronRight, LogOut, History } from 'lucide-react';
import type { User } from '../utils/storage';

interface SettingsScreenProps {
  user: User;
  onLogout: () => void;
  onViewHistory: () => void;
}

export function SettingsScreen({ user, onLogout, onViewHistory }: SettingsScreenProps) {
  const settingsItems = [
    { label: 'Notifications', value: 'On' },
    { label: 'Dark Mode', value: 'Off' },
    { label: 'Sound Effects', value: 'On' },
    { label: 'Default Category', value: 'Personal' },
  ];

  return (
    <div className="flex flex-col h-full bg-gray-50">
      <div className="bg-blue-600 text-white p-6">
        <h1 className="text-2xl">Settings</h1>
        <p className="text-blue-100 mt-1">Manage your preferences</p>
      </div>

      <div className="flex-1 overflow-auto">
        {/* User Profile */}
        <div className="p-4">
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white text-xl">
                {user.name.charAt(0).toUpperCase()}
              </div>
              <div>
                <h3 className="text-gray-900">{user.name}</h3>
                <p className="text-sm text-gray-500">{user.email}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="p-4 space-y-2">
          <h2 className="text-sm text-gray-500 px-4 py-2">QUICK ACTIONS</h2>
          <button
            onClick={onViewHistory}
            className="w-full bg-white rounded-lg p-4 flex items-center justify-between shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex items-center gap-3">
              <History className="w-5 h-5 text-indigo-600" />
              <span className="text-gray-900">View Task History</span>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        <div className="p-4 space-y-2">
          <h2 className="text-sm text-gray-500 px-4 py-2">GENERAL</h2>
          {settingsItems.map((item, index) => (
            <div
              key={index}
              className="bg-white rounded-lg p-4 flex items-center justify-between shadow-sm"
            >
              <span className="text-gray-900">{item.label}</span>
              <div className="flex items-center gap-2">
                <span className="text-gray-500">{item.value}</span>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 space-y-2 mt-4">
          <h2 className="text-sm text-gray-500 px-4 py-2">ABOUT</h2>
          <div className="bg-white rounded-lg p-4 shadow-sm space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-700">Version</span>
              <span className="text-gray-500">1.0.0</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-700">Build</span>
              <span className="text-gray-500">2025.12.27</span>
            </div>
          </div>
        </div>

        <div className="p-4 mt-4 space-y-2">
          <button className="w-full bg-red-50 text-red-600 py-3 rounded-lg hover:bg-red-100 transition-colors">
            Clear All Tasks
          </button>
          
          <button 
            onClick={onLogout}
            className="w-full bg-gray-100 text-gray-700 py-3 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center gap-2"
          >
            <LogOut className="w-5 h-5" />
            Logout
          </button>
        </div>
      </div>
    </div>
  );
}