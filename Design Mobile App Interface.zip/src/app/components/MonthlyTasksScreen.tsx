import { useState } from 'react';
import { CalendarDays, Plus, ChevronLeft, ChevronRight } from 'lucide-react';
import { TodoItem } from './TodoItem';

interface Task {
  id: string;
  title: string;
  completed: boolean;
  category: string;
  dueDate?: string;
  isMonthlyTask?: boolean;
}

interface MonthlyTasksScreenProps {
  tasks: Task[];
  onToggleTask: (id: string) => void;
  onDeleteTask: (id: string) => void;
  onAddMonthlyTask: () => void;
}

export function MonthlyTasksScreen({
  tasks,
  onToggleTask,
  onDeleteTask,
  onAddMonthlyTask,
}: MonthlyTasksScreenProps) {
  const [currentDate, setCurrentDate] = useState(new Date());

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const currentMonth = currentDate.getMonth();
  const currentYear = currentDate.getFullYear();

  const navigateMonth = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    if (direction === 'prev') {
      newDate.setMonth(currentMonth - 1);
    } else {
      newDate.setMonth(currentMonth + 1);
    }
    setCurrentDate(newDate);
  };

  // Filter tasks for current month
  const monthlyTasks = tasks.filter((task) => {
    if (!task.dueDate) return false;
    const taskDate = new Date(task.dueDate);
    return (
      taskDate.getMonth() === currentMonth &&
      taskDate.getFullYear() === currentYear
    );
  });

  // Group tasks by week
  const getWeekOfMonth = (date: Date) => {
    const firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
    const firstDayOfWeek = firstDay.getDay();
    return Math.ceil((date.getDate() + firstDayOfWeek) / 7);
  };

  const tasksByWeek: { [key: number]: Task[] } = {};
  monthlyTasks.forEach((task) => {
    if (task.dueDate) {
      const taskDate = new Date(task.dueDate);
      const week = getWeekOfMonth(taskDate);
      if (!tasksByWeek[week]) tasksByWeek[week] = [];
      tasksByWeek[week].push(task);
    }
  });

  const completedCount = monthlyTasks.filter((t) => t.completed).length;
  const totalCount = monthlyTasks.length;

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-6">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => navigateMonth('prev')}
            className="p-2 hover:bg-white/20 rounded-full transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          
          <div className="text-center">
            <h1 className="text-2xl">{monthNames[currentMonth]}</h1>
            <p className="text-purple-100">{currentYear}</p>
          </div>
          
          <button
            onClick={() => navigateMonth('next')}
            className="p-2 hover:bg-white/20 rounded-full transition-colors"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CalendarDays className="w-5 h-5" />
            <span>{totalCount} tasks this month</span>
          </div>
          <div className="text-purple-100">
            {completedCount}/{totalCount} completed
          </div>
        </div>

        {/* Progress Bar */}
        {totalCount > 0 && (
          <div className="mt-3 bg-white/20 rounded-full h-2 overflow-hidden">
            <div
              className="bg-white h-full transition-all duration-300"
              style={{ width: `${(completedCount / totalCount) * 100}%` }}
            />
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto">
        {totalCount === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 px-6">
            <div className="text-6xl mb-4">📅</div>
            <h2 className="text-xl text-gray-600 mb-2">No tasks this month</h2>
            <p className="text-gray-400 text-center mb-6">
              Add tasks with due dates to see them here
            </p>
            <button
              onClick={onAddMonthlyTask}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg flex items-center gap-2 hover:bg-blue-700 transition-colors"
            >
              <Plus className="w-5 h-5" />
              Add Monthly Task
            </button>
          </div>
        ) : (
          <div className="p-4 space-y-6">
            {[1, 2, 3, 4, 5].map((week) => {
              const weekTasks = tasksByWeek[week] || [];
              if (weekTasks.length === 0) return null;

              return (
                <div key={week}>
                  <h2 className="text-sm text-gray-500 mb-2 px-2">
                    WEEK {week}
                  </h2>
                  <div className="bg-white rounded-lg overflow-hidden shadow-sm">
                    {weekTasks.map((task) => (
                      <TodoItem
                        key={task.id}
                        {...task}
                        onToggle={onToggleTask}
                        onDelete={onDeleteTask}
                      />
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Floating Add Button */}
      {totalCount > 0 && (
        <button
          onClick={onAddMonthlyTask}
          className="absolute bottom-20 right-4 w-14 h-14 bg-blue-600 text-white rounded-full shadow-lg flex items-center justify-center hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-6 h-6" />
        </button>
      )}
    </div>
  );
}
