// Local storage utilities for demo purposes
// NOTE: This is NOT secure for production use!

export interface User {
  id: string;
  email: string;
  name: string;
}

export interface StoredUser extends User {
  password: string; // In real apps, NEVER store plain passwords!
}

export interface Task {
  id: string;
  title: string;
  completed: boolean;
  category: string;
  userId: string;
  createdAt: string;
  dueDate?: string;
  isMonthlyTask?: boolean;
}

// User Management
export const getUsers = (): StoredUser[] => {
  const users = localStorage.getItem('todo_users');
  return users ? JSON.parse(users) : [];
};

export const saveUser = (user: StoredUser): void => {
  const users = getUsers();
  users.push(user);
  localStorage.setItem('todo_users', JSON.stringify(users));
};

export const findUser = (email: string, password: string): StoredUser | null => {
  const users = getUsers();
  return users.find(u => u.email === email && u.password === password) || null;
};

export const getUserByEmail = (email: string): StoredUser | null => {
  const users = getUsers();
  return users.find(u => u.email === email) || null;
};

// Session Management
export const saveCurrentUser = (user: User): void => {
  localStorage.setItem('todo_current_user', JSON.stringify(user));
};

export const getCurrentUser = (): User | null => {
  const user = localStorage.getItem('todo_current_user');
  return user ? JSON.parse(user) : null;
};

export const logout = (): void => {
  localStorage.removeItem('todo_current_user');
};

// Task Management
export const getTasks = (userId: string): Task[] => {
  const tasks = localStorage.getItem(`todo_tasks_${userId}`);
  return tasks ? JSON.parse(tasks) : [];
};

export const saveTasks = (userId: string, tasks: Task[]): void => {
  localStorage.setItem(`todo_tasks_${userId}`, JSON.stringify(tasks));
};

export const addTask = (userId: string, task: Task): void => {
  const tasks = getTasks(userId);
  tasks.unshift(task);
  saveTasks(userId, tasks);
};

export const updateTask = (userId: string, taskId: string, updates: Partial<Task>): void => {
  const tasks = getTasks(userId);
  const index = tasks.findIndex(t => t.id === taskId);
  if (index !== -1) {
    tasks[index] = { ...tasks[index], ...updates };
    saveTasks(userId, tasks);
  }
};

export const deleteTask = (userId: string, taskId: string): void => {
  const tasks = getTasks(userId);
  saveTasks(userId, tasks.filter(t => t.id !== taskId));
};

// Initialize demo account if not exists
export const initializeDemoAccount = () => {
  const users = getUsers();
  const demoExists = users.find(u => u.email === 'demo@example.com');
  
  if (!demoExists) {
    const demoUser: StoredUser = {
      id: 'demo-user-1',
      email: 'demo@example.com',
      password: 'demo123',
      name: 'Demo User',
    };
    saveUser(demoUser);
    
    // Add demo tasks
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const nextWeek = new Date(today);
    nextWeek.setDate(nextWeek.getDate() + 7);
    
    const demoTasks: Task[] = [
      {
        id: '1',
        title: 'Review project proposal',
        completed: false,
        category: 'Work',
        userId: 'demo-user-1',
        createdAt: today.toISOString(),
        dueDate: today.toISOString().split('T')[0],
      },
      {
        id: '2',
        title: 'Buy groceries',
        completed: false,
        category: 'Shopping',
        userId: 'demo-user-1',
        createdAt: today.toISOString(),
        dueDate: tomorrow.toISOString().split('T')[0],
      },
      {
        id: '3',
        title: 'Morning workout',
        completed: true,
        category: 'Health',
        userId: 'demo-user-1',
        createdAt: today.toISOString(),
      },
      {
        id: '4',
        title: 'Prepare monthly report',
        completed: false,
        category: 'Work',
        userId: 'demo-user-1',
        createdAt: today.toISOString(),
        dueDate: nextWeek.toISOString().split('T')[0],
      },
    ];
    
    saveTasks('demo-user-1', demoTasks);
  }
};
